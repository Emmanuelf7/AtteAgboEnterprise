﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplicationHardWare
{
    public partial class frmLogIn : Sample
    {
             
        public frmLogIn()
        {
            InitializeComponent();
            
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            

            if (MainClass.IsValidUser(txtUsername.Text, txtPassword.Text) == false)
            {
                MessageBox.Show("Invalid username or password");
                return;
               
            }
            else
            {
                int i;
               
                for (i=0; i <= 5000; i++ )
                {
                    progressBar1.Increment(1);
                }
                   
                frmMain frm = new frmMain();
                frm.Show();
                this.Hide();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
