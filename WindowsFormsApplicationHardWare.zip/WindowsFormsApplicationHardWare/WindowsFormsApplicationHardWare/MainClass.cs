﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplicationHardWare
{
    class MainClass
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";
      
//@"Data Source=EMMAPC\SQLEXPRESS;Initial Catalog=WindowsFormsPOS;Integrated Security=True";

        public static SqlConnection con = new SqlConnection(con_string);

        // Method to check user valivation
        public static bool IsValidUser(string user, string pass)
        {
            bool isValid = false;
            string qry = @"Select * from tblUsers where uUsername='" + user + "' and uPassword='" + pass + "' ";
            SqlCommand cmd = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                isValid = true;
                USER = dt.Rows[0]["uName"].ToString();
                Byte[] imageArray = (byte[])dt.Rows[0]["uImage"];
                byte[] imageByteArray = imageArray;
                IMG = Image.FromStream(new MemoryStream(imageArray));
            }

            return isValid;
        }

        public static void StopBuffering(Panel ctr, bool doubleBuffer)
        {
            try
            {
                typeof(Control).InvokeMember("DoubleBuffer",
                    BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.SetProperty,
                    null, ctr, new object[] { doubleBuffer });
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        // create property for username

        public static string user;

        public static string USER
        {
            get { return user; }
            private set { user = value; }
        }

        // for user image
        public static Image img;
        public static Image IMG
        {
            get { return img; }
            private set { img = value; }
        }
        // Method for crud operation
        public static int SQL(string qry, Hashtable ht)
        {
            int res = 0;
            try
            {
                SqlCommand cmd = new SqlCommand(qry, con);
                cmd.CommandType = CommandType.Text;
                foreach (DictionaryEntry item in ht)
                {
                    cmd.Parameters.AddWithValue(item.Key.ToString(), item.Value);

                }
                if (con.State == ConnectionState.Closed) { con.Open(); }
                res = cmd.ExecuteNonQuery();
                if (con.State == ConnectionState.Open) { con.Close(); }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                con.Close();

            }
            return res;
        }

        // For loading data from database
        public static void LoadData(string qry, DataGridView gv, ListBox lb)
        {
            // Serial number in GridView
            gv.CellFormatting += new DataGridViewCellFormattingEventHandler(gv_CellFormatting);
            try
            {
                SqlCommand cmd = new SqlCommand(qry, con);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                for (int i = 0; i < lb.Items.Count; i++)
                {
                    string colNam1 = ((DataGridViewColumn)lb.Items[i]).Name;
                    gv.Columns[colNam1].DataPropertyName = dt.Columns[i].ToString();
                }
                gv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();
        }

        //public void DisplayData(string Table, DataGridView DGV)
        //{
        //    con.Open();
        //    string Query = "select * from " + Table+ "";
        //    SqlDataAdapter sda = new SqlDataAdapter(Query, con);
        //    SqlCommandBuilder Builder = new SqlCommandBuilder(sda);
        //    var ds = new DataSet();
        //    sda.Fill(ds);
        //    DGV.DataSource = ds.Tables[0];
        //    con.Close();
        //}
        private static void gv_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            
        }

        // for blur screen
        public static void BlurBackground(Form Model)
        {
            Form Background = new Form();
            using (Model)
            {
                Background.StartPosition = FormStartPosition.Manual;
                Background.FormBorderStyle = FormBorderStyle.None;
                Background.Opacity = 0.5d;
                Background.BackColor = Color.Black;
                Background.Size = frmMain.Instance.Size;
                Background.Location = frmMain.Instance.Location;
                Background.ShowInTaskbar = false;
                Background.Show();
                Model.Owner = Background;
                Model.ShowDialog(Background);
                Background.Dispose();
            }
        }
        // for CB fill
        public static void CBFill(string qry, ComboBox cb)
        {
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cb.DisplayMember = "uName";
            cb.ValueMember = "id";
            cb.DataSource = dt;
            cb.SelectedIndex = -1;
        }

        public static void CBFill(string qry, ComboBox cb, string displayMember, string valueMember)
        {
            SqlCommand sqlCommand = new SqlCommand(qry, con);
            sqlCommand.CommandType = CommandType.Text;
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);
            cb.DataSource = dataTable;
            cb.DisplayMember = displayMember;
            cb.ValueMember = valueMember;
            cb.SelectedIndex = -1;
        }

        public static bool Validation(Form F)
        {
            bool isValid = false;

            int count = 0;
            foreach (Control c in F.Controls)
            {
                // using tag of the control to check if we want to validate it or not
                if (Convert.ToString(c.Tag) != "" && Convert.ToString(c.Tag) != null)
                {
                    // for textbox
                    if (c is System.Windows.Forms.TextBox)
                    {
                        System.Windows.Forms.TextBox t = (System.Windows.Forms.TextBox)c;
                        if (t.Text.Trim() == "")
                        {

                            t.BackColor = Color.Red;
                            
                            count++;

                        }
                        else
                        {
                            t.BackColor = Color.FromArgb(213, 218, 223);
                            
                        }
                    }
                    // for combobox
                    if (c is System.Windows.Forms.ComboBox)
                    {
                        System.Windows.Forms.ComboBox t = (System.Windows.Forms.ComboBox)c;
                        if (t.SelectedIndex == -1)
                        {

                            t.BackColor = Color.Red;                          
                            count++;

                        }
                        else
                        {
                            t.BackColor = Color.FromArgb(213, 218, 223);
                            
                        }
                    }
                }
                if (count == 0)
                {
                    isValid = true;
                }
                else
                {
                    isValid = false;
                }
            }
            return isValid;
        }
    }
}
