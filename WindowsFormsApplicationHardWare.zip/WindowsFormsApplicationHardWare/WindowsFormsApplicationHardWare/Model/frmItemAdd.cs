﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplicationHardWare.Model
{
    public partial class frmItemAdd : SampleAdd
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";

        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        public frmItemAdd()
        {
            InitializeComponent();
            GetCategory();
            
        }
        public int id = 0;
        public int CatID = 0;
        public decimal Profit = 0;
        private void txtQty_TextChanged(object sender, EventArgs e)
        {

        }
        private void Clear()
        {
            btnAdd.Enabled = true;
            btnEdit.Enabled = false;
            txtProduct.Clear();
            cmbCategory.Text = "";
            txtBuyingPrice.Clear();
            txtSellingPrice.Clear();
            txtQty.Clear();
            txtQuantityInHistory.Clear();
            txtProductDetails.Clear();
            txtProduct.Focus();
        }

        private void GetCategory()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select CatId, CatName from tblCategory", con);
            SqlDataReader Rdr;
            Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
          //  dt.Columns.Add("CatName", typeof(string));
            dt.Load(Rdr);
            cmbCategory.ValueMember = "CatId";
            cmbCategory.DisplayMember = "CatName";
            cmbCategory.DataSource = dt;
            Rdr.Close();
            con.Close();

        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtProduct.Text == "" || txtProductDetails.Text == "" || txtSellingPrice.Text == "" || txtBuyingPrice.Text == "" || txtQty.Text == "" || txtQuantityInHistory.Text == "")
            {
                MessageBox.Show("Missing Information !!!");
            }
            else
            {
                try
                {
                    decimal Profit = Convert.ToDecimal(txtSellingPrice.Text) - Convert.ToDecimal(txtBuyingPrice.Text);
                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into tblItem(ItName, ItCat, ItQty,ItQtyInHistory,ItBprice,ItSprice,ItProfit,ItDetails,ItStockInDate)values(@name,@catid, @qty,@qtyInHistory, @bPrice,@sPrice,@profit,@details,@stockinDate)", con);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@name", txtProduct.Text);
                    cmd.Parameters.AddWithValue("@catid", Convert.ToInt32(cmbCategory.SelectedValue));
                    cmd.Parameters.AddWithValue("@qty", txtQty.Text);
                    cmd.Parameters.AddWithValue("@qtyInHistory", txtQuantityInHistory.Text);
                    cmd.Parameters.AddWithValue("@bPrice", txtBuyingPrice.Text);
                    cmd.Parameters.AddWithValue("@sPrice", txtSellingPrice.Text);
                    cmd.Parameters.AddWithValue("@profit", Profit);
                    cmd.Parameters.AddWithValue("@details", txtProductDetails.Text);
                    cmd.Parameters.Add("@StockInDate", SqlDbType.Date).Value = dtStockInDate.Value;
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Product successfully saved !!!");
                    Clear();
                    GetCategory();
                    
                }

                catch (Exception Ex)
                {

                    con.Close();
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void frmItemAdd_Load(object sender, EventArgs e)
        {
            GetCategory();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Please confirm if you want to update the product?", "UPDATE", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    decimal Profit = Convert.ToDecimal(txtSellingPrice.Text) - Convert.ToDecimal(txtBuyingPrice.Text);
                    con.Open();
                    cmd = new SqlCommand("update tblItem SET ItName=@name,ItCat=@Cat,ItQty=@Qty,ItQtyInHistory=@qtyInHistory, ItBprice=@Bprice, ItSprice=@Sprice, ItProfit=@Profit, ItDetails=@Details, ItStockInDate=@StockInDate  where ItId like '" + id + "'", con);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@catid", CatID);
                    cmd.Parameters.AddWithValue("@name", txtProduct.Text);                    
                    cmd.Parameters.AddWithValue("@Cat", Convert.ToInt32(cmbCategory.SelectedValue));
                    cmd.Parameters.AddWithValue("@Qty", txtQty.Text);
                    cmd.Parameters.AddWithValue("@qtyInHistory", txtQuantityInHistory.Text);
                    cmd.Parameters.AddWithValue("@Bprice", txtBuyingPrice.Text);
                    cmd.Parameters.AddWithValue("@Sprice", txtSellingPrice.Text);
                    cmd.Parameters.AddWithValue("@Profit", Profit);
                    cmd.Parameters.AddWithValue("@Details", txtProductDetails.Text);                   
                    cmd.Parameters.Add("@StockInDate", SqlDbType.Date).Value = dtStockInDate.Value;
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("This Product has been successfully updated!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();

                }
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);

            }
        }
    }
}
