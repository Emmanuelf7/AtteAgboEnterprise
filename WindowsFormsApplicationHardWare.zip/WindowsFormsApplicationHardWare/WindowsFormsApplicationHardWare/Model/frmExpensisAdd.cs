﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplicationHardWare.Model
{
    public partial class frmExpensisAdd : SampleAdd
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";

        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        public frmExpensisAdd()
        {
            InitializeComponent();
        }
        public int id = 0;
        private void Clear()
        {
            btnAdd.Enabled = true;
            btnEdit.Enabled = false;
            txtProduct.Clear();          
            txtCostPrice.Clear();
            txtTotalPrice.Clear();
            txtQuantity.Clear();
            txtRemark.Clear();
            txtProduct.Focus();
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtProduct.Text == "" || txtRemark.Text == "" || txtTotalPrice.Text == "" || txtCostPrice.Text == "")
            {
                MessageBox.Show("Missing Information !!!");
            }
            else
            {
                try
                {
                    
                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into tblExpensis(EDate, EDescription, Qty,Cost,Total,Remark)values(@date,@description, @qty, @cost,@total,@remark)", con);
                    cmd.Parameters.AddWithValue("@id", id);                  
                    cmd.Parameters.Add("@date", SqlDbType.Date).Value = dtExpensisDate.Value;
                    cmd.Parameters.AddWithValue("@description", txtProduct.Text);
                    cmd.Parameters.AddWithValue("@qty", txtQuantity.Text);
                    cmd.Parameters.AddWithValue("@cost", txtCostPrice.Text);
                    cmd.Parameters.AddWithValue("@total", txtTotalPrice.Text);
                    cmd.Parameters.AddWithValue("@remark", txtRemark.Text);    
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Expensis successfully saved !!!");
                    Clear();
                   

                }

                catch (Exception Ex)
                {

                    con.Close();
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
             try
            {
                if (MessageBox.Show("Please confirm if you want to update this expesis?", "UPDATE", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    
                    con.Open();
                    cmd = new SqlCommand("update tblExpensis SET EDate=@date,EDescription=@description,Qty=@qty,Cost=@cost, Total=@total, Remark=@remark where ExpenID like '" + id + "'", con);
                    cmd.Parameters.AddWithValue("@id", id);                    
                     cmd.Parameters.Add("@date", SqlDbType.Date).Value = dtExpensisDate.Value;
                    cmd.Parameters.AddWithValue("@description", txtProduct.Text);                                    
                    cmd.Parameters.AddWithValue("@qty", txtQuantity.Text);                 
                    cmd.Parameters.AddWithValue("@cost", txtCostPrice.Text);
                    cmd.Parameters.AddWithValue("@total", txtTotalPrice.Text);
                    cmd.Parameters.AddWithValue("@remark", txtRemark.Text);                   
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("This Expensis has been successfully updated!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();

                }
            }
            catch (Exception ex)
            {
               
                MessageBox.Show(ex.Message);

            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }
        }
    }

