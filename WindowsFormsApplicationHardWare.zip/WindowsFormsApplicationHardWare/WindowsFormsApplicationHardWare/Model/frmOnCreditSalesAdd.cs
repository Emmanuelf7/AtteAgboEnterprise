﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplicationHardWare.Model
{
    public partial class frmOnCreditSalesAdd : Form
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";

        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        public frmOnCreditSalesAdd()
        {
            InitializeComponent();
        }

        private void txtCostPrice_TextChanged(object sender, EventArgs e)
        {

        }

        public int id = 0;
        private void Clear()
        {
            btnAdd.Enabled = true;
            btnUpdate.Enabled = false;
            txtProduct.Clear();
            txtSellingPrice.Clear();
            txtAmountPaid.Clear();
            txtQuantity.Clear();
            txtBalance.Clear();
            txtCustomersName.Clear();
            txtAmountPaid.Clear();
            txtPhoneNo.Clear();
            txtProduct.Focus();
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtProduct.Text == "" || txtQuantity.Text == "" || txtSellingPrice.Text == "" || txtAmountPaid.Text == "" || txtBalance.Text == "" || txtCustomersName.Text == "")
            {
                MessageBox.Show("Missing Information !!!");
            }
            else
            {
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into tblOnCredit(CDate, CDescription, Qty,CSellingPrice,CAmountPaid,CBalance,CustomersName,Phone)values(@Cdate,@Cdescription, @Cqty, @CsellingPrice,@CamountPaid,@Cbalance,@customername,@phone)", con);
                    cmd.Parameters.AddWithValue("@id", id);
                  //  cmd.Parameters.AddWithValue("@Cdate", dtStockInDate.Value.ToString("dd-MM-yyyy"));
                    cmd.Parameters.Add("@Cdate", SqlDbType.Date).Value = dtSOnCreditDate.Value;
                    cmd.Parameters.AddWithValue("@Cdescription", txtProduct.Text);
                    cmd.Parameters.AddWithValue("@Cqty", txtQuantity.Text);
                    cmd.Parameters.AddWithValue("@CsellingPrice", txtSellingPrice.Text);
                    cmd.Parameters.AddWithValue("@CamountPaid", txtAmountPaid.Text);
                    cmd.Parameters.AddWithValue("@Cbalance", txtBalance.Text);
                    cmd.Parameters.AddWithValue("@customername", txtCustomersName.Text);
                    cmd.Parameters.AddWithValue("@phone", txtPhoneNo.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Item bought on credit successfully saved !!!");
                    Clear();


                }

                catch (Exception Ex)
                {

                    con.Close();
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
             try
            {
                if (MessageBox.Show("Please confirm if you want to update item bought on credit?", "UPDATE", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    
                    con.Open();
                    cmd = new SqlCommand("update tblOnCredit SET CDate=@date, CDescription=@description, CSellingPrice=@sellingPrice, Qty=@qty, CAmountPaid=@amountPaid, CBalance=@balance, CustomersName=@customername, Phone=@phone where CreditId like '" + id + "'", con);
                    cmd.Parameters.AddWithValue("@id", id);                  
                    cmd.Parameters.Add("@date", SqlDbType.Date).Value = dtSOnCreditDate.Value;
                    cmd.Parameters.AddWithValue("@description", txtProduct.Text);                  
                    cmd.Parameters.AddWithValue("@sellingPrice", txtSellingPrice.Text);
                    cmd.Parameters.AddWithValue("@qty", txtQuantity.Text);
                    cmd.Parameters.AddWithValue("@amountPaid", txtAmountPaid.Text);
                    cmd.Parameters.AddWithValue("@balance", txtBalance.Text);
                    cmd.Parameters.AddWithValue("@customername", txtCustomersName.Text);
                    cmd.Parameters.AddWithValue("@phone", txtPhoneNo.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("This record has been successfully updated!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();

                }
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
                

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        }
        }
    

