﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplicationHardWare.Model
{
    public partial class frmUpdateBillAdd : SampleAdd
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";
        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        public frmUpdateBillAdd()
        {
            InitializeComponent();
        }
        public int id = 0;

        private void Clear()
        {

            txtProductName.Clear();
            txtCustomer.Clear();          
            txtSellingPrice.Clear();
            txtQuantity.Clear();
            txtTotal.Clear();
            txtProductName.Focus();
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Please confirm if you want to update the Sales?", "UPDATE", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    decimal Total = Convert.ToDecimal(txtSellingPrice.Text) * Convert.ToInt32(txtQuantity.Text);
                    con.Open();
                    cmd = new SqlCommand("update tblSales SET SDate=@date,SProductName=@productName,SPrice=@price,SQty=@qty, SAmount=@amount, SCustomer=@customer  where SNum like '" + id + "'", con);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@date", dtBillindDate.Value.ToString("dd-MM-yyyy"));
                    cmd.Parameters.AddWithValue("@productName", txtProductName.Text);
                    cmd.Parameters.AddWithValue("@price", txtSellingPrice.Text);
                    cmd.Parameters.AddWithValue("@qty", txtQuantity.Text);
                    cmd.Parameters.AddWithValue("@amount", Total);
                    cmd.Parameters.AddWithValue("@customer", txtCustomer.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("This Sales has been successfully updated!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();

                }
            }
            catch (Exception ex)
            {
               
                MessageBox.Show(ex.Message);

            }
        }
    }
     
}
