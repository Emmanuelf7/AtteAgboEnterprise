﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplicationHardWare.View;

namespace WindowsFormsApplicationHardWare.Model
{
    public partial class frmCategoryAdd : SampleAdd
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";

        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        frmCategoryView fmList;
        public frmCategoryAdd(frmCategoryView flist)
        {
            InitializeComponent();
            this.fmList = flist;
        }
        public int id = 0;

        private void Clear()
        {
            btnAdd.Enabled = true;
            btnEdit.Enabled = false;
            txtName.Clear();
            txtName.Focus();
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                MessageBox.Show("Missing Information !!!");
            }
            else
            {
                try
                {
                    
                        con.Open();                     
                        SqlCommand cmd = new SqlCommand("insert into tblCategory(CatName)values(@cat)", con);
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@cat", txtName.Text);
                        cmd.ExecuteNonQuery();
                        con.Close();
                        MessageBox.Show("Category successfully saved !!!");                       
                        Clear();
                        
                    }
                
                catch (Exception Ex)
                {
                    con.Close();
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Please confirm if you want to update the category?", "UPDATE", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    con.Open();
                    cmd = new SqlCommand("update tblCategory SET CatName=@catName where CatId like '" + id + "'", con);
                    cmd.Parameters.AddWithValue("catName", txtName.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("1 Category has been successfully updated!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                                      
                }
            }
            catch (Exception ex)
            {
               con.Open();
                MessageBox.Show(ex.Message);
              
            }
        }

       


    }
}
