﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplicationHardWare.View;
using Tulpep.NotificationWindow;
namespace WindowsFormsApplicationHardWare
{
    public partial class frmMain : Sample
    {
        static frmMain _obj;
        public static frmMain Instance
        {
            get { if (_obj == null)
            {
                _obj = new frmMain();
            }
            return _obj;
            }
        }
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            _obj = this;

            lblUser.Text = MainClass.USER;
            pictureBox1.Image = MainClass.img;
            btnHome.PerformClick();
        }

        public void AddControls(Form f)
        {
            this.panel3.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            panel3.Controls.Add(f);
            f.Show();
        }

       

        private void btnUsers_Click(object sender, EventArgs e)
        {
            
        }

        private void btnUsers_Click_1(object sender, EventArgs e)
        {
            AddControls(new frmUserView());
        }

        private void btnCategory_Click(object sender, EventArgs e)
        {
            AddControls(new frmCategoryView());
        }

        private void btnProduct_Click(object sender, EventArgs e)
        {
            AddControls(new frmItemView());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AddControls(new frmBilling());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AddControls(new frmDashBoard());
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AddControls(new frmSalesAnalyticReport());
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            AddControls(new frmUpdateBillView());
        }

        private void button7_Click(object sender, EventArgs e)
        {
            AddControls(new frmExpensisView());
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Logout Application?", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide();
                frmLogIn frm = new frmLogIn();
                frm.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddControls(new frmOnCreditSalesView());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddControls(new frmSalesAnalyticReportView());
        }
    }
}
