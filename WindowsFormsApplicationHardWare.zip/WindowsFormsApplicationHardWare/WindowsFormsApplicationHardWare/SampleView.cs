﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplicationHardWare
{
    public partial class SampleView : Sample
    {
        public SampleView()
        {
            InitializeComponent();
        }

        private void SampleView_Load(object sender, EventArgs e)
        {

        }

        public virtual void btnAdd_Click(object sender, EventArgs e)
        {

        }

        public virtual void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

       public  virtual void pictureBox2_Click(object sender, EventArgs e)
        {
          
            this.Close();
    
        }
    }
}
