﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplicationHardWare.Model;

namespace WindowsFormsApplicationHardWare.View
{
    public partial class frmBilling : Form
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";
        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public string stitle;
        
        public frmBilling()
        {
            InitializeComponent();
            
           // LoadProducts();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        int n = 0;
        decimal GrandTotal = 0;

        public void UpdateItem()
        {
            
            try
            {

                con.Open();                
                cmd = new SqlCommand("update tblItem set ItQty = ItQty - " + Int32.Parse(txtQuantity.Text) + "where ItId like '" + Int32.Parse(dataGridView1.SelectedRows[0].Cells[1].Value.ToString()) + "%'", con);            
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("This Product has been successfully addedd!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
              
            }
            catch (Exception ex)
            {
                
                MessageBox.Show(ex.Message);

            }
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtQuantity.Text == "" || Convert.ToInt32(txtQuantity.Text) > Stock)
            {
                MessageBox.Show("Enter a Valid Quantity !!!");
            }
            else
            {
                decimal total = Int32.Parse(txtQuantity.Text) * Convert.ToDecimal(txtSellingPrice.Text);
                DataGridViewRow newRow = new DataGridViewRow();
                newRow.CreateCells(DGVClientBill);
                newRow.Cells[0].Value = n + 1;
                newRow.Cells[1].Value = txtProductName.Text;
                newRow.Cells[2].Value = txtSellingPrice.Text;
                newRow.Cells[3].Value = txtQuantity.Text;
                newRow.Cells[4].Value = total;
                DGVClientBill.Rows.Add(newRow);
                GrandTotal = GrandTotal + total;
                lblGrandTotal.Text = "Ghc" + GrandTotal;
                n++;
               UpdateItem();
               LoadProducts();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtSellingPrice.Text = "";
            txtQuantity.Text = "";
            txtProductName.Text = "";
            Stock = 0;
            GrandTotal = 0;
            lblGrandTotal.Text = "";
            DGVClientBill.Rows.Clear();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtSellingPrice.Text = "";
            txtQuantity.Text = "";
            txtProductName.Text = "";
            txtCustomer.Text = "";
            Stock = 0;
            GrandTotal = 0;
            lblGrandTotal.Text = "";
            DGVClientBill.Rows.Clear();
        }

        public void LoadProducts()
        {
            int i = 0;
            dataGridView1.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("select i.ItId,i.ItName,i.ItCat,c.CatName, i.ItQty,i.ItBprice,i.ItSprice,i.ItProfit,i.ItDetails,i.ItStockInDate from tblItem as i inner join  tblCategory  c on  c.CatId=i.ItCat where ItName like '%" + txtSearch.Text + "%'", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView1.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString(), dr[7].ToString(), dr[8].ToString(), dr[9].ToString());
            }
            dr.Close();
            con.Close();
        }

        private void frmBilling_Load(object sender, EventArgs e)
        {
            LoadProducts();
            
        }

       
        int Stock = 0;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtProductName.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvName"].Value);
            Stock = Convert.ToInt32(dataGridView1.CurrentRow.Cells["dgvQty"].Value.ToString());
            txtSellingPrice.Text = Convert.ToDecimal(dataGridView1.CurrentRow.Cells["dgvSellingPrice"].Value).ToString("#0.00");
        }
       
        public int id = 0;
        
      
        private void SaveBill()
        {
            try
            {
                if (DGVClientBill.Rows.Count > 0)
                {
                    // update product qty
                    if (MessageBox.Show("Please confirm if you want to save this record?", stitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        for (int i = 0; i < DGVClientBill.Rows.Count; i++)
                        {
                            con.Open();
                            SqlCommand cmd = new SqlCommand("insert into tblSales(SDate,SProductName,SPrice,SQty, SAmount,SCustomer)values(@sDate,@sProductName,@sPrice,@sQty, @sAmount,@sCustomer)", con);
                            cmd.Parameters.AddWithValue("@sDate", dtBillindDate.Value.ToString("dd-MM-yyyy"));
                            cmd.Parameters.AddWithValue("@sProductName", DGVClientBill.Rows[i].Cells["dgvProduct"].Value.ToString());
                            cmd.Parameters.AddWithValue("@sPrice", DGVClientBill.Rows[i].Cells["dgvSellingPrice2"].Value.ToString());
                            cmd.Parameters.AddWithValue("@sQty", DGVClientBill.Rows[i].Cells["dgvQunatity"].Value.ToString());
                            cmd.Parameters.AddWithValue("@sAmount", Convert.ToDecimal(DGVClientBill.Rows[i].Cells["dgvTotal"].Value.ToString()));
                            cmd.Parameters.AddWithValue("@sCustomer", txtCustomer.Text);
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }

                        MessageBox.Show("Bill successfully saved !", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                       
                    }
                }
            }
            catch (Exception Ex)
            {
                con.Close();
                MessageBox.Show(Ex.Message);
            }
        }

       
       
        private void button2_Click(object sender, EventArgs e)
        {
            SaveBill();
           
            frmPrintReceipt frm = new frmPrintReceipt(this);
            frm.LoadReceipt();
            frm.ShowDialog();
           MessageBox.Show("Payment successfully saved!", "Payment", MessageBoxButtons.OK, MessageBoxIcon.Information);
            DGVClientBill.Rows.Clear();
            lblGrandTotal.Text = "";
            GrandTotal = 0;
        }
        
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            
        }

        public void SalesDeduction()
        {
           
            double total = 0;
            lblGrandTotal.Text = "";
            foreach (DataGridViewRow item in DGVClientBill.Rows)
            {
                total += double.Parse(item.Cells["dgvTotal"].Value.ToString());
            }
            lblGrandTotal.Text = total.ToString("N2");
        }
        private void DGVClientBill_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (DGVClientBill.CurrentCell.OwningColumn.Name == "dgvEdit")
            {
                int rowindex = DGVClientBill.CurrentCell.RowIndex;
                DGVClientBill.Rows.RemoveAt(rowindex);
                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["dgvIDD"].Value);
            }
            else if (DGVClientBill.CurrentCell.OwningColumn.Name == "dgvDelete")
            {
                if (MessageBox.Show("Please confirm if you want to delete this record?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int rowindex = DGVClientBill.CurrentCell.RowIndex;
                    DGVClientBill.Rows.RemoveAt(rowindex);
                    int id = Convert.ToInt32(DGVClientBill.CurrentRow.Cells["dgvIDD"].Value);
                    con.Open();
                    cmd = new SqlCommand("delete from tblSales where SNum =" + id + "", con);                 
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Record has been successfully deleted!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SalesDeduction();
                }
            }
          
        }
           

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadProducts();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
           
        }
       
        private void printDocument1_PrintPage_1(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
          
        }

        private void button1_Click_3(object sender, EventArgs e)
        {
           
        }

        private void btnCalculator_Click(object sender, EventArgs e)
        {
            frmCalculator frm = new frmCalculator();
            frm.ShowDialog();
        }
        }
    }
 