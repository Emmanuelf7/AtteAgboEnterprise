﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplicationHardWare.Model;

namespace WindowsFormsApplicationHardWare.View
{
    public partial class frmItemView : SampleView
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";
        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public frmItemView()
        {
            InitializeComponent();
        }

        private void frmItemView_Load(object sender, EventArgs e)
        {
            LoadItemFromDatabase();
        }

        public override void btnAdd_Click(object sender, EventArgs e)
        {
            MainClass.BlurBackground(new frmItemAdd());
           
            LoadItemFromDatabase();
        }

        public override void txtSearch_TextChanged(object sender, EventArgs e)
        {
           
            int i = 0;
            dataGridView1.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("select i.ItId,i.ItName, c.CatId,c.CatName,i.ItQty,i.ItQtyInHistory, i.ItBprice,i.ItSprice,i.ItProfit,i.ItDetails,i.ItStockInDate from tblItem i inner join  tblCategory  c on  c.CatId=i.ItCat where CatName like '%" + txtSearch.Text + "%' or ItName like '%" + txtSearch.Text + "%'", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i++;
                // Parse the FDate column as a DateTime object
                DateTime fDate = Convert.ToDateTime(dr["ItStockInDate"]);
                // Format the date as dd/MM/yyyy
                string formattedFDate = fDate.ToString("dd/MM/yyyy");

                dataGridView1.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString(), dr[7].ToString(), dr[8].ToString(), dr[9].ToString(), formattedFDate);
            }
            dr.Close();
            con.Close();
        }

        public void LoadItemFromDatabase()
        {
            int i = 0;
            dataGridView1.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("select i.ItId,i.ItName, c.CatId,c.CatName,i.ItQty,i.ItQtyInHistory, i.ItBprice,i.ItSprice,i.ItProfit,i.ItDetails,i.ItStockInDate from tblItem i inner join  tblCategory  c on  c.CatId=i.ItCat where CatName like '%" + txtSearch.Text + "%'", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i++;
                // Parse the FDate column as a DateTime object
                DateTime fDate = Convert.ToDateTime(dr["ItStockInDate"]);
                // Format the date as dd/MM/yyyy
                string formattedFDate = fDate.ToString("dd/MM/yyyy");

                dataGridView1.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString(), dr[7].ToString(), dr[8].ToString(), dr[9].ToString(), formattedFDate);
            }
            dr.Close();
            con.Close();
        }
        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
             if (dataGridView1.CurrentCell.OwningColumn.Name == "dgvEdit")
            {
               
                frmItemAdd frm = new frmItemAdd();
                frm.btnAdd.Enabled = false;
                frm.btnEdit.Enabled = true;
                frm.id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["dgvID"].Value);
                frm.CatID = Convert.ToInt32(dataGridView1.CurrentRow.Cells["dgvCatId"].Value);
                frm.txtProduct.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvName"].Value);
                frm.cmbCategory.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvCategory"].Value);
                frm.txtQty.Text = Convert.ToInt32(dataGridView1.CurrentRow.Cells["dgvQty"].Value).ToString();
                frm.txtQuantityInHistory.Text = Convert.ToInt32(dataGridView1.CurrentRow.Cells["dgvQuantityInHistory"].Value).ToString();
                frm.txtBuyingPrice.Text = Convert.ToDecimal(dataGridView1.CurrentRow.Cells["dgvBuyingPrice"].Value).ToString("#0.00");
                frm.txtSellingPrice.Text = Convert.ToDecimal(dataGridView1.CurrentRow.Cells["dgvSellingPrice"].Value).ToString("#0.00");
                frm.Profit = Convert.ToDecimal(dataGridView1.CurrentRow.Cells["dgvProfit"].Value);
                frm.txtProductDetails.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvItemDetail"].Value);
                frm.dtStockInDate.CustomFormat = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvStockInDate"].Value); 
                MainClass.BlurBackground(frm);
                LoadItemFromDatabase();
            }
            else if (dataGridView1.CurrentCell.OwningColumn.Name == "dgvDelete")
            {
                if (MessageBox.Show("Please confirm if you want to Delete this Product?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {


                    con.Open();
                    cmd = new SqlCommand("delete from tblItem where ItId like '" + dataGridView1.Rows[e.RowIndex].Cells["dgvid"].Value.ToString() + "'", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Product has been successfully deleted!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadItemFromDatabase();
                }

            }

        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            frmPrintProduct frm = new frmPrintProduct(this);
            frm.LoadPrintProduct();
            frm.Show();
        }

        private void txtSearch_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
