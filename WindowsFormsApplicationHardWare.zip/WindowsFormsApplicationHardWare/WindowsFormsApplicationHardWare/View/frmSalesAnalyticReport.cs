﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplicationHardWare.View
{
    public partial class frmSalesAnalyticReport : Form
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";
        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public frmSalesAnalyticReport()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void LoadSales()
        {
            int i = 0;
            DGVSalesRport.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("select SNum, SDate,SProductName,SPrice,SQty,SAmount, SCustomer from tblSales ", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i++;
                DGVSalesRport.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString());
            }
            dr.Close();
            con.Close();
        }
     
        private void frmSalesAnalyticReport_Load(object sender, EventArgs e)
        {
            LoadSales();
        }

        private void dtSoldDate1_ValueChanged(object sender, EventArgs e)
        {
            //LoadSalesRecordByDate();
        }

        private void dtSoldDate2_ValueChanged(object sender, EventArgs e)
        {
          //  LoadSalesRecordByDate();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadSales();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            frmPrintSalesReportView frm = new frmPrintSalesReportView();
            frm.LoadSoldItems("select SNum,SDate, SProductName, SPrice,SQty, sum(SQty) as tot_SQty,  sum(SAmount) as SAmount from tblSales where SDate between '" + dtSoldDate1.Value.ToString("dd-MM-yyyy") + "'and '" + dtSoldDate2.Value.ToString("dd-MM-yyyy") + "'group by SNum, SDate, SProductName, SPrice,SQty", "From-:" + dtSoldDate1.Value.ToString("dd-MM-yyyy") + "-To:-" + dtSoldDate2.Value.ToString("dd-MM-yyyy"));
            frm.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            double _total = 0;
            int i = 0;
            DGVSalesRport.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("Select * from tblSales where SDate between'" + dtSoldDate1.Value.ToString("dd-MM-yyyy") + "'and'" + dtSoldDate2.Value.ToString("dd-MM-yyyy") + "%'", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i += 1;
                _total += double.Parse(dr["SAmount"].ToString());
                DGVSalesRport.Rows.Add(i, dr["SNum"].ToString(), dr["SDate"].ToString(), dr["SProductName"].ToString(), dr["SPrice"].ToString(), dr["SQty"].ToString(), dr["SAmount"].ToString(), dr["SCustomer"].ToString());
            }
            dr.Close();
            con.Close();
            lblTotal.Text = _total.ToString("Ghc #,##0.00");
        }

        private void DGVSalesRport_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
