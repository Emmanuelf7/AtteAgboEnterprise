﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplicationHardWare.View
{
    public partial class frmSalesAnalyticReportView : SampleView
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";
        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public frmSalesAnalyticReportView()
        {
            InitializeComponent();
        }

        private void loadSalesReport()
        {
            double _total = 0;
            int i = 0;
            DGVSalesRport.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("Select  SProductName,sum(SPrice)as tot_SPrice,sum(SQty) as tot_SQty,sum(SAmount) as tot_SAmount from tblSales where SDate between'" + dtSoldDate1.Value.ToString("dd-MM-yyyy") + "'and'" + dtSoldDate2.Value.ToString("dd-MM-yyyy") + "%'group by  SProductName", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i += 1;
                _total += double.Parse(dr["tot_SAmount"].ToString());
                DGVSalesRport.Rows.Add(i, dr["SProductName"].ToString(), dr["tot_SPrice"].ToString(), int.Parse(dr["tot_SQty"].ToString()), dr["tot_SAmount"].ToString());
            }
            dr.Close();
            con.Close();
            lblTotal.Text = _total.ToString("Ghc #,##0.00");
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dtSoldDate1_ValueChanged(object sender, EventArgs e)
        {
            loadSalesReport();
        }

        private void dtSoldDate2_ValueChanged(object sender, EventArgs e)
        {
            loadSalesReport();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
