﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplicationHardWare.View
{
    public partial class frmDashBoard : Form
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";
//@"Data Source=EMMAPC\SQLEXPRESS;Initial Catalog=WindowsFormsPOS;Integrated Security=True";
        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
      
        public frmDashBoard()
        {
            InitializeComponent();
            CountItem();
            CountQuantity();
            CountDailySales();
        }

        public void CountItem()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from tblItem", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lblStockIn.Text = dt.Rows[0][0].ToString();

            con.Close();
        }

        public void CountQuantity()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select isnull(sum(ItQty),0) as ItQty from tblItem", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lblQuantity.Text = "Qty "+ dt.Rows[0][0].ToString();

            con.Close();
        }

        public void CountDailySales()
        {
            string sdate = DateTime.Now.ToString("dd-MM-yyyy");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select isnull(sum(SAmount),0) as SAmount from tblSales where SDate between '" + sdate + "'and'" + sdate + "  '", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lblSales.Text ="Ghc "+ dt.Rows[0][0].ToString();
            con.Close();
        }

       
    }
}
