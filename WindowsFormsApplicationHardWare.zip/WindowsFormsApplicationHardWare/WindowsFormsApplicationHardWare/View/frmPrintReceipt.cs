﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplicationHardWare.View
{
    public partial class frmPrintReceipt : Form
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";
        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        frmBilling fm;

        string store = "Roskal Enterprise";
        string location = "Madina Recko Overheard";
        string phone = "Phone no: 0277401974";
        public frmPrintReceipt(frmBilling fmliist)
        {
            InitializeComponent();
            this.fm = fmliist;
        }

        private void frmPrintReceipt_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }

        //public void LoadReport()
        //{
        //    ReportDataSource rptReportDataSource;
        //    try
        //    {
        //        this.reportViewer1.LocalReport.ReportPath = Application.StartupPath + @"\rptReceipt.rdlc";
        //        this.reportViewer1.LocalReport.DataSources.Clear();
        //        DataSet ds = new DataSet();
        //        SqlDataAdapter da = new SqlDataAdapter();

        //        con.Open();
        //        da.SelectCommand = new SqlCommand("select SNum, SDate,SProductName,SPrice,SQty,SAmount, SCustomer from tblSales where  convert(varchar(10), SDate, 102) = convert(varchar(10), getdate(), 102)", con);

        //      // da.SelectCommand = new SqlCommand("select SNum, SDate,SProductName,SPrice,SQty,SAmount, SCustomer from tblSales where SDate like '%" + fm.dtBillindDate+"%'", con);
        //        da.Fill(ds.Tables["dtReceipt"]);
        //        con.Close();
        //        ReportParameter pTotal = new ReportParameter("pTotal", fm.lblGrandTotal.Text);                            
        //        ReportParameter pStore = new ReportParameter("pStore", store);
        //        ReportParameter pAddress = new ReportParameter("pAddress", address);
        //        ReportParameter pPhone = new ReportParameter("pPhone", phone);
        //       // ReportParameter pCustomer = new ReportParameter("pCash", fm.txtCustomer.Text); 

        //        reportViewer1.LocalReport.SetParameters(pTotal);                            
        //        reportViewer1.LocalReport.SetParameters(pStore);
        //        reportViewer1.LocalReport.SetParameters(pAddress);
        //        reportViewer1.LocalReport.SetParameters(pPhone);
        //     // reportViewer1.LocalReport.SetParameters(pCustomer); 
        //        rptReportDataSource = new ReportDataSource("DataSet1", ds.Tables["dtReceipt"]);
        //        reportViewer1.LocalReport.DataSources.Add(rptReportDataSource);
        //        reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
        //        reportViewer1.ZoomMode = ZoomMode.Percent;
        //        reportViewer1.ZoomPercent = 100;
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}

        
        public void LoadReceipt()
        {
        
       ReportDataSource rptReportDataSource;
    try
    {
        DataTable dtReceipt = new DataTable();
      
        dtReceipt.Columns.Add("SProductName", typeof(string));
        dtReceipt.Columns.Add("SPrice", typeof(decimal));
        dtReceipt.Columns.Add("SQty", typeof(int));
        dtReceipt.Columns.Add("SAmount", typeof(decimal));

        this.reportViewer1.LocalReport.ReportPath = Application.StartupPath + @"\Reports\rptReceipt.rdlc";
        this.reportViewer1.LocalReport.DataSources.Clear();

        foreach (DataGridViewRow dgvRow in fm.DGVClientBill.Rows)
        {
            DataRow dataRow = dtReceipt.NewRow();
           
            
            dataRow["SProductName"] = dgvRow.Cells["dgvProduct"].Value.ToString();
            dataRow["SPrice"] = Convert.ToDecimal(dgvRow.Cells["dgvSellingPrice2"].Value);
            dataRow["SQty"] = Convert.ToInt32(dgvRow.Cells["dgvQunatity"].Value);
            dataRow["SAmount"] = Convert.ToDecimal(dgvRow.Cells["dgvTotal"].Value);

           
            dtReceipt.Rows.Add(dataRow);
          
        }

        ReportParameter pTotal = new ReportParameter("pTotal", fm.lblGrandTotal.Text);
        ReportParameter pStore = new ReportParameter("pStore", store);
        ReportParameter pAddress = new ReportParameter("pAddress", location);
        ReportParameter pPhone = new ReportParameter("pPhone", phone);

        reportViewer1.LocalReport.SetParameters(pTotal);
        reportViewer1.LocalReport.SetParameters(pStore);
        reportViewer1.LocalReport.SetParameters(pAddress);
        reportViewer1.LocalReport.SetParameters(pPhone);
        rptReportDataSource = new ReportDataSource("DataSet1", dtReceipt);
        reportViewer1.LocalReport.DataSources.Add(rptReportDataSource);
        reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
        reportViewer1.ZoomMode = ZoomMode.Percent;
        reportViewer1.ZoomPercent = 100;
    }
    catch (Exception ex)
    {
        MessageBox.Show(ex.Message);
    }
}
        }


    }



    

