﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplicationHardWare.View
{
    public partial class frmPrintProduct : Form
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";
        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        frmItemView fm;
        public frmPrintProduct(frmItemView fmlist)
        {
            InitializeComponent();
            this.fm = fmlist;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmPrintProduct_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }
        public void LoadPrintProduct()
        {
            try
            {
                ReportDataSource rptDS;
                this.reportViewer1.LocalReport.ReportPath = Application.StartupPath + @"\Reports\rptProduct.rdlc";
                this.reportViewer1.LocalReport.DataSources.Clear();
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter();
                con.Open();
                da.SelectCommand = new SqlCommand("select i.ItId,i.ItName, c.CatId,c.CatName,i.ItQty,i.ItQtyInHistory,i.ItBprice,i.ItSprice,i.ItProfit,i.ItDetails,i.ItStockInDate from tblItem as i inner join  tblCategory as  c on  c.CatId=i.ItCat where CatName like '%" + fm.txtSearch.Text + "%'", con);
                da.Fill(ds.Tables["dtProduct"]);
                rptDS = new ReportDataSource("DataSet1", ds.Tables["dtProduct"]);
                reportViewer1.LocalReport.DataSources.Add(rptDS);
                reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
                reportViewer1.ZoomMode = ZoomMode.Percent;
                reportViewer1.ZoomPercent = 100;
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }
    }
}
