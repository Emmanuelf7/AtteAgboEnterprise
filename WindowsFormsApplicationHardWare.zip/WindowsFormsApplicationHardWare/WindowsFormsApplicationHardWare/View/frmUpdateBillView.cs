﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplicationHardWare.Model;

namespace WindowsFormsApplicationHardWare.View
{
    public partial class frmUpdateBillView : Form
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";
        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public frmUpdateBillView()
        {
            InitializeComponent();
        }

        private void frmUpdateBillView_Load(object sender, EventArgs e)
        {
            LoadSales();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void LoadSales()
        {
            int i = 0;
            DGVSalesRport.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("select SNum, SDate,SProductName,SPrice,SQty,SAmount, SCustomer from tblSales where SCustomer like '%" + txtSearch.Text + "%'", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i++;
                DGVSalesRport.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString());
            }
            dr.Close();
            con.Close();
        }
      
        private void DGVSalesRport_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (DGVSalesRport.CurrentCell.OwningColumn.Name == "dgvEdit")
            {
               
                frmUpdateBillAdd frm = new frmUpdateBillAdd();
                frm.id = Convert.ToInt32(DGVSalesRport.CurrentRow.Cells["dgvID"].Value);
                frm.dtBillindDate.Text = Convert.ToString(DGVSalesRport.CurrentRow.Cells["dgvDate"].Value);
                frm.txtProductName.Text = Convert.ToString(DGVSalesRport.CurrentRow.Cells["dgvProduct"].Value);
                frm.txtSellingPrice.Text = Convert.ToDecimal(DGVSalesRport.CurrentRow.Cells["dgvSellingPrice"].Value).ToString("#0.00");
                frm.txtQuantity.Text = Convert.ToInt32(DGVSalesRport.CurrentRow.Cells["dgvQty"].Value).ToString();
                frm.txtTotal.Text = Convert.ToDecimal(DGVSalesRport.CurrentRow.Cells["dgvTotal"].Value).ToString("#0.00");              
                frm.txtCustomer.Text = Convert.ToString(DGVSalesRport.CurrentRow.Cells["dgvCustomer"].Value);
                MainClass.BlurBackground(frm);
                LoadSales();
            }
            else if (DGVSalesRport.CurrentCell.OwningColumn.Name == "dgvDelete")
            {
                if (MessageBox.Show("Please confirm if you want to Delete this Sales?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {


                    con.Open();
                    cmd = new SqlCommand("delete from tblSales where SNum like '" + DGVSalesRport.Rows[e.RowIndex].Cells["dgvid"].Value.ToString() + "'", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Sales has been successfully deleted!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadSales();
                }

            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadSales();
        }

    }
}
