﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplicationHardWare.Model;

namespace WindowsFormsApplicationHardWare.View
{
    public partial class frmUserView : Form
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";

        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public frmUserView()
        {
            InitializeComponent();
           
        }

        private void frmUserView_Load(object sender, EventArgs e)
        {
            LoadUserRecord();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public virtual void btnAdd_Click(object sender, EventArgs e)
        {
            MainClass.BlurBackground(new frmUserAdd());
            LoadUserRecord();
        }

        public virtual void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadUserRecord();
        }

        private void LoadUserRecord()
        {
            int i = 0;
            dataGridView1.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("select userID,uName, uUsername, uPassword, uPhoneNo, uImage from tblUsers where uName like '%" + txtSearch.Text + "%'", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView1.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString());
            }
            dr.Close();
            con.Close();


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentCell.OwningColumn.Name == "dgvEdit")
            {
                frmUserAdd frm = new frmUserAdd();
                frm.id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["dgvID"].Value);
                frm.txtName.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvName"].Value);
                frm.txtUsername.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvUsername"].Value);
                frm.txtPassword.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvPassword"].Value);
                frm.txtPhoneNo.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvPhone"].Value);

                MainClass.BlurBackground(frm);
                LoadUserRecord();
            }
            else if (dataGridView1.CurrentCell.OwningColumn.Name == "dgvDelete")
            {
                if (MessageBox.Show("Please confirm if you want to Delete this user?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {


                    con.Open();
                    cmd = new SqlCommand("delete from tblUsers where userID like '" + dataGridView1.Rows[e.RowIndex].Cells["dgvid"].Value.ToString() + "'", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("A user has been successfully deleted!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadUserRecord();
                }

            }
        }

        private void txtSearch_TextChanged_1(object sender, EventArgs e)
        {
            LoadUserRecord();
        }

        //private void btnAdd_Click(object sender, EventArgs e)
        //{

        //}
    }
}
