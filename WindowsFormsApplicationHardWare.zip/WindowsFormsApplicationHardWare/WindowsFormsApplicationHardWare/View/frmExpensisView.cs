﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplicationHardWare.Model;

namespace WindowsFormsApplicationHardWare.View
{
    public partial class frmExpensisView : SampleView
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";
        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public frmExpensisView()
        {
            InitializeComponent();
        }

        private void frmExpensisView_Load(object sender, EventArgs e)
        {
            LoadExpensisRecord();
        }
        public override void btnAdd_Click(object sender, EventArgs e)
        {
            MainClass.BlurBackground(new frmExpensisAdd());
            LoadExpensisRecord();
        }
        public override void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadExpensisRecord();
        }

        private void LoadExpensisRecord()
        {
            int i = 0;
            dataGridView1.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("select ExpenID,EDate,EDescription,Cost,Qty,Total,Remark from tblExpensis where EDescription like '%" + txtSearch.Text + "%'", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i++;
                // Parse the FDate column as a DateTime object
                DateTime fDate = Convert.ToDateTime(dr["EDate"]);
                // Format the date as dd/MM/yyyy
                string formattedFDate = fDate.ToString("dd/MM/yyyy");
                dataGridView1.Rows.Add(i, dr[0].ToString(), formattedFDate, dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString());
            }
            dr.Close();
            con.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            frmPrintExpensisView frm = new frmPrintExpensisView();
            frm.LoadExpensis("select ExpenID,EDate, EDescription, Cost,Qty,Total,Remark, sum(Qty) as tot_Qty,  sum(Total) as Total from tblExpensis where EDate between '" + dtExpensis1.Value.ToString("dd-MM-yyyy") + "'and '" + dtdtExpensis2.Value.ToString("dd-MM-yyyy") + "'group by ExpenID, EDate, EDescription, Qty,Cost,Total,Remark", "From-:" + dtExpensis1.Value.ToString("dd-MM-yyyy") + "-To:-" + dtdtExpensis2.Value.ToString("dd-MM-yyyy"));
            frm.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            double _total = 0;
            int i = 0;
            dataGridView1.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("Select * from tblExpensis where EDate between'" + dtExpensis1.Value.ToString("dd/MM/yyyy") + "'and'" + dtdtExpensis2.Value.ToString("dd/MM/yyyy") + "%'", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i += 1;
                // Parse the FDate column as a DateTime object
                DateTime fDate = Convert.ToDateTime(dr["EDate"]);
                // Format the date as dd/MM/yyyy
                string formattedFDate = fDate.ToString("dd/MM/yyyy");
                _total += double.Parse(dr["Total"].ToString());
                dataGridView1.Rows.Add(i, dr["ExpenID"].ToString(), formattedFDate, dr["EDescription"].ToString(), dr["Cost"].ToString(), dr["Qty"].ToString(), dr["Total"].ToString(), dr["Remark"].ToString());
            }
            dr.Close();
            con.Close();
            lblTotal.Text = _total.ToString("Ghc #,##0.00");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentCell.OwningColumn.Name == "dgvEdit")
            {

                frmExpensisAdd frm = new frmExpensisAdd();
                frm.btnAdd.Enabled = false;
                frm.btnEdit.Enabled = true;
                frm.id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["dgvID"].Value);
                frm.dtExpensisDate.CustomFormat = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvDate"].Value);
                frm.txtProduct.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvDescription"].Value);
                frm.txtCostPrice.Text = Convert.ToDecimal(dataGridView1.CurrentRow.Cells["dgvCost"].Value).ToString("#0.00");
                frm.txtQuantity.Text = Convert.ToUInt32(dataGridView1.CurrentRow.Cells["dgvQty"].Value).ToString();
                frm.txtTotalPrice.Text = Convert.ToDecimal(dataGridView1.CurrentRow.Cells["dgvTotal"].Value).ToString("#0.00");
                frm.txtRemark.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvRemark"].Value);
               
                MainClass.BlurBackground(frm);
               LoadExpensisRecord();
            }
            else if (dataGridView1.CurrentCell.OwningColumn.Name == "dgvDelete")
            {
                if (MessageBox.Show("Please confirm if you want to Delete this expensis?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {


                    con.Open();
                    cmd = new SqlCommand("delete from tblExpensis where ExpenID like '" + dataGridView1.Rows[e.RowIndex].Cells["dgvID"].Value.ToString() + "'", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Expensis has been successfully deleted!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                  LoadExpensisRecord();
                }

            }

        }


    }
}
