﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplicationHardWare.Model;

namespace WindowsFormsApplicationHardWare.View
{
    public partial class frmOnCreditSalesView : SampleView
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";
           
        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public frmOnCreditSalesView()
        {
            InitializeComponent();
            
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            MainClass.BlurBackground(new frmOnCreditSalesAdd());
            LoadBoughtOnCreditRecord();
        }

        private void LoadBoughtOnCreditRecord()
        {
            int i = 0;
            dataGridView1.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("select CreditId,CDate,CDescription,CSellingPrice,Qty,CAmountPaid,CBalance,CustomersName,Phone from tblOnCredit where CustomersName like '%" + txtSearch.Text + "%'", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i++;
                // Parse the FDate column as a DateTime object
                DateTime fDate = Convert.ToDateTime(dr["CDate"]);
                // Format the date as dd/MM/yyyy
                string formattedFDate = fDate.ToString("dd/MM/yyyy");

                dataGridView1.Rows.Add(i, dr[0].ToString(), formattedFDate, dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString(), dr[7].ToString(), dr[8].ToString());
            }
            dr.Close();
            con.Close();

        }

        private void txtSearch_TextChanged_1(object sender, EventArgs e)
        {
            LoadBoughtOnCreditRecord();
        }

        private void frmOnCreditSalesView_Load(object sender, EventArgs e)
        {
            LoadBoughtOnCreditRecord();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentCell.OwningColumn.Name == "dgvEdit")
            {

                frmOnCreditSalesAdd frm = new frmOnCreditSalesAdd();
                frm.btnAdd.Enabled = false;
                frm.btnUpdate.Enabled = true;
                frm.id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["dgvID"].Value);
                frm.dtSOnCreditDate.CustomFormat = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvDate"].Value);
                frm.txtProduct.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvDescription"].Value);
                frm.txtSellingPrice.Text = Convert.ToDecimal(dataGridView1.CurrentRow.Cells["dgvSellingPrice"].Value).ToString("#0.00");
                frm.txtQuantity.Text = Convert.ToInt32(dataGridView1.CurrentRow.Cells["dgvQty"].Value).ToString();
                frm.txtAmountPaid.Text = Convert.ToDecimal(dataGridView1.CurrentRow.Cells["dgvAmountPaid"].Value).ToString("#0.00");
                frm.txtBalance.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvBalance"].Value);
                frm.txtCustomersName.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvCustomerName"].Value);
                frm.txtPhoneNo.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvPhoneNo"].Value);
                MainClass.BlurBackground(frm);
                LoadBoughtOnCreditRecord();
            }
            else if (dataGridView1.CurrentCell.OwningColumn.Name == "dgvDelete")
            {
                if (MessageBox.Show("Please confirm if you want to Delete this record?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {


                    con.Open();
                    cmd = new SqlCommand("delete from tblOnCredit where CreditId like '" + dataGridView1.Rows[e.RowIndex].Cells["dgvID"].Value.ToString() + "'", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("This record has been successfully deleted!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadBoughtOnCreditRecord();
                }

            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            frmPrintOnCreditSalesReport frm = new frmPrintOnCreditSalesReport(this);
            frm.LoadOnCreditSalesReport();
            frm.Show();
        }


    }
}
