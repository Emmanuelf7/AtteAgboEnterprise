﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplicationHardWare.Model;

namespace WindowsFormsApplicationHardWare.View
{
    public partial class frmCategoryView : SampleView
    {
        public static readonly string con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\App_Data\WindowsFormsHardwarePOS.mdf;Initial Catalog=WindowsFormsHardwarePOS;Integrated Security=True";

        public static SqlConnection con = new SqlConnection(con_string);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        public frmCategoryView()
        {
            InitializeComponent();
        }

        private void frmCategoryView_Load(object sender, EventArgs e)
        {
            LoadCategoryRecord();
        }
        public override void btnAdd_Click(object sender, EventArgs e)
        {
            MainClass.BlurBackground(new frmCategoryAdd(this));            
            LoadCategoryRecord();
        }

        public override void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public override void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadCategoryRecord();
        }
        private void LoadCategoryRecord()
        {
            int i = 0;
            dataGridView1.Rows.Clear();
            con.Open();
            cmd = new SqlCommand("select CatId,CatName from tblCategory where CatName like '%" + txtSearch.Text + "%'", con);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView1.Rows.Add(i, dr[0].ToString(), dr[1].ToString());
            }
            dr.Close();
            con.Close();


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentCell.OwningColumn.Name == "dgvEdit")
            {

                frmCategoryAdd frm = new frmCategoryAdd(this);
                frm.btnAdd.Enabled = false;
                frm.btnEdit.Enabled = true;
                frm.id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["dgvID"].Value);
                frm.txtName.Text = Convert.ToString(dataGridView1.CurrentRow.Cells["dgvName"].Value);                
                MainClass.BlurBackground(frm);
                LoadCategoryRecord();
            }
            else if (dataGridView1.CurrentCell.OwningColumn.Name == "dgvDelete")
            {
                if (MessageBox.Show("Please confirm if you want to Delete this category?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {


                    con.Open();
                    cmd = new SqlCommand("delete from tblCategory where CatId like '" + dataGridView1.Rows[e.RowIndex].Cells["dgvid"].Value.ToString() + "'", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Category has been successfully deleted!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadCategoryRecord();
                }

            }

        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {

        }
    }
}
