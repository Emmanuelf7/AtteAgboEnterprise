﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POS_and_Inventory_Management_System.CASHIER
{
   public class  Product
    {
       public int ProductId { get; set; }
     public string ProductCode { get; set; }
        public string ProductName { get; set; } 
        public string Category { get; set; }
        public int StockInQty { get; set; }
        public decimal Price { get; set; }
        public decimal TaxPercentage { get; set; }
        public decimal CostPrice { get; set; }
   }
    }

