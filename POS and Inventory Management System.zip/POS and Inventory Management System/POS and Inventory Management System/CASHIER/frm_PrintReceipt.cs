﻿using Microsoft.Reporting.WinForms;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_and_Inventory_Management_System.CASHIER
{
    public partial class frm_PrintReceipt : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        dbConnection dbcon = new dbConnection();
        dbConnection con = new dbConnection();

        string companyName = "Jbea Enterprise";
        string address = "Sch. Junction off Adjringanor rd";
        string phone = "Phone #: 024 463 6433";
        frm_mainCashier flist;
        public frm_PrintReceipt(frm_mainCashier f)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            this.flist=f;
        }

        private void frm_PrintReceipt_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }

        //public void LoadReceipt()
        //{
        //     ReportDataSource rptReportDataSource;
        //    try
        //    {
        //        this.reportViewer1.LocalReport.ReportPath = Application.StartupPath + @"\Report\rptReceipt.rdlc";
        //        this.reportViewer1.LocalReport.DataSources.Clear();
        //        DataSet ds = new DataSet();
        //        SqlDataAdapter da = new SqlDataAdapter();

        //        cn.Open();
        //        da.SelectCommand = new SqlCommand("select SalesId, TransactionNo, TransactionDate,bmonth, bmothyear,ProductCode, ProductName, category, price, tax,qty,totalProductPrice,totalPriceqty,discount from tblSales where TransactionNo like '" + flist.lbl_TransactionNo.Text + "'", cn);
        //        da.Fill(ds.Tables["dtSalesReport"]);
        //        cn.Close();

        //        ReportParameter pTax = new ReportParameter("pTax", flist.lbl_TotalTax.Text);
        //        ReportParameter pDiscount = new ReportParameter("pDiscount", flist.lbl_Discount.Text);
        //        ReportParameter pTotal = new ReportParameter("pTotal", flist.lbl_OverallGrandTotal.Text);
        //        ReportParameter pAmountReceived = new ReportParameter("pAmountReceived", flist.txt_AmountReceived.Text);
        //        ReportParameter pChange = new ReportParameter("pChange", flist.lbl_Change.Text);
        //        ReportParameter pCompanyName = new ReportParameter("pCompanyName", companyName);
        //        ReportParameter pAddress = new ReportParameter("pAddress", address);
        //        ReportParameter pPhoneNo = new ReportParameter("pPhoneNo", phone);
        //        ReportParameter pTransactionNo = new ReportParameter("pTransactionNo", "Receipt #:" + flist.lbl_TransactionNo.Text);
        //        ReportParameter pCashier = new ReportParameter("pCashier", flist.lblUser.Text);

        //        reportViewer1.LocalReport.SetParameters(pTax);
        //        reportViewer1.LocalReport.SetParameters(pDiscount);
        //        reportViewer1.LocalReport.SetParameters(pTotal);
        //        reportViewer1.LocalReport.SetParameters(pAmountReceived);
        //        reportViewer1.LocalReport.SetParameters(pChange);
        //        reportViewer1.LocalReport.SetParameters(pCompanyName);
        //        reportViewer1.LocalReport.SetParameters(pAddress);
        //        reportViewer1.LocalReport.SetParameters(pPhoneNo);
        //        reportViewer1.LocalReport.SetParameters(pTransactionNo);
        //        reportViewer1.LocalReport.SetParameters(pCashier);
        //        rptReportDataSource = new ReportDataSource("DataSet1", ds.Tables["dtSalesReport"]);
        //        reportViewer1.LocalReport.DataSources.Add(rptReportDataSource);
        //        reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
        //        reportViewer1.ZoomMode = ZoomMode.Percent;
        //        reportViewer1.ZoomPercent = 100;
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}

        public void LoadReceipt()
        {
            ReportDataSource rptReportDataSource;
            try
            {
                DataTable dtReceipt = new DataTable();
                dtReceipt.Columns.Add("ProductName", typeof(string));
                dtReceipt.Columns.Add("price", typeof(decimal));
                dtReceipt.Columns.Add("qty", typeof(int));
                dtReceipt.Columns.Add("totalPriceqty", typeof(decimal));


                this.reportViewer1.LocalReport.ReportPath = Application.StartupPath + @"\Report\rptReceipt.rdlc";
                this.reportViewer1.LocalReport.DataSources.Clear();
                DataSet ds = new DataSet();


                foreach (DataGridViewRow dgvRow in flist.dataGridView1.Rows)
                {
                    DataRow dataRow = dtReceipt.NewRow();
                    dataRow["ProductName"] = dgvRow.Cells["Column3"].Value.ToString();
                    dataRow["price"] = Convert.ToDecimal(dgvRow.Cells["Column5"].Value);
                    dataRow["qty"] = Convert.ToInt32(dgvRow.Cells["Column8"].Value);
                    dataRow["totalPriceqty"] = Convert.ToDecimal(dgvRow.Cells["Column9"].Value);


                    dtReceipt.Rows.Add(dataRow);

                }

                ReportParameter pTax = new ReportParameter("pTax", flist.lbl_TotalTax.Text);
                ReportParameter pDiscount = new ReportParameter("pDiscount", flist.lbl_Discount.Text);
                ReportParameter pTotal = new ReportParameter("pTotal", flist.lbl_OverallGrandTotal.Text);
                ReportParameter pAmountReceived = new ReportParameter("pAmountReceived", flist.txt_AmountReceived.Text);
                ReportParameter pChange = new ReportParameter("pChange", flist.lbl_Change.Text);
                ReportParameter pCompanyName = new ReportParameter("pCompanyName", companyName);
                ReportParameter pAddress = new ReportParameter("pAddress", address);
                ReportParameter pPhoneNo = new ReportParameter("pPhoneNo", phone);
                ReportParameter pTransactionNo = new ReportParameter("pTransactionNo", "Receipt #:" + flist.lbl_TransactionNo.Text);
                ReportParameter pCashier = new ReportParameter("pCashier", flist.lblUser.Text);

                reportViewer1.LocalReport.SetParameters(pTax);
                reportViewer1.LocalReport.SetParameters(pDiscount);
                reportViewer1.LocalReport.SetParameters(pTotal);
                reportViewer1.LocalReport.SetParameters(pAmountReceived);
                reportViewer1.LocalReport.SetParameters(pChange);
                reportViewer1.LocalReport.SetParameters(pCompanyName);
                reportViewer1.LocalReport.SetParameters(pAddress);
                reportViewer1.LocalReport.SetParameters(pPhoneNo);
                reportViewer1.LocalReport.SetParameters(pTransactionNo);
                reportViewer1.LocalReport.SetParameters(pCashier);
                rptReportDataSource = new ReportDataSource("DataSet1", dtReceipt);
                reportViewer1.LocalReport.DataSources.Add(rptReportDataSource);
                reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
                reportViewer1.ZoomMode = ZoomMode.Percent;
                reportViewer1.ZoomPercent = 100;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        }
    }

