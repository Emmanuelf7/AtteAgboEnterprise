﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_and_Inventory_Management_System.ADMIN
{
    public partial class frm_SalesRecord : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        dbConnection dbcon = new dbConnection();
        SqlDataReader dr;
        public frm_SalesRecord()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //public void LoadSalesReport()
        //{
        //    int i = 0;
        //    double _total = 0;
        //    dataGridView2.Rows.Clear();
        //    try
        //    {         
        //    cn.Open();
        //    cm = new SqlCommand("select ProductCode,  ProductName,price, sum(tax) as tot_tax, sum(qty)as tot_qty,sum(totalProductPrice) as tot_totalProductPrice,sum(discount)as tot_discount,sum(totalPriceqty) as tot_totalPriceqty from tblSales where TransactionDate between'" + dtSales1.Value.ToString("dd-MM-yyyy") + "' and'" + dtSales2.Value.ToString("dd-MM-yyyy") + "' group by  ProductCode, ProductName,price", cn);
          
        //    dr = cm.ExecuteReader();

        //    while (dr.Read())
        //    {
        //        i += 1;
               
        //        _total += double.Parse(dr["tot_totalPriceqty"].ToString());
        //        dataGridView2.Rows.Add(i, dr["ProductCode"].ToString(), dr["ProductName"].ToString(), dr["price"].ToString(), dr["tot_tax"].ToString(), dr["tot_qty"].ToString(), dr["tot_totalProductPrice"].ToString(), dr["tot_discount"].ToString(), dr["tot_totalPriceqty"].ToString());
        //        lblTotal.Text = _total.ToString("#,##0.00");
        //    }
        //    }
        //    //dr.Close();
        //    //cn.Close();           
        //    catch (Exception ex)
        //    {
        //        // Handle or log the exception appropriately
        //        Console.WriteLine("Error: " + ex.Message);
        //    }
        //    finally
        //    {
        //        dr.Close();
        //        cn.Close();
        //    }
        //}

        private void dtSales1_ValueChanged(object sender, EventArgs e)
        {
            //LoadSalesReport();
        }

        private void dtSales2_ValueChanged(object sender, EventArgs e)
        {
            //LoadSalesReport();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            frmSalesRecordPrintPreview frm = new frmSalesRecordPrintPreview(this);
            frm.LoadSalesRecord("select ProductCode,  ProductName,price, Isnull( sum(tax),0) as tot_tax,Isnull( sum(qty),0)as tot_qty,Isnull(sum(totalProductPrice),0) as tot_totalProductPrice,Isnull(sum(discount),0)as tot_discount,Isnull(sum(totalPriceqty),0) as tot_totalPriceqty,Isnull(sum(profit),0) as tot_profit  from tblSales where TransactionDate between'" + dtSales1.Value.ToString("dd-MM-yyyy") + "' and'" + dtSales2.Value.ToString("dd-MM-yyyy") + "' group by  ProductCode, ProductName,price ", "From-:" + dtSales1.Value.ToString("dd-MM-yyyy") + "-To:-" + dtSales2.Value.ToString("dd-MM-yyyy"));
            frm.Show();
        }

        private void btnLoadData_Click(object sender, EventArgs e)
        {
            int i = 0;
            double _total = 0;
            double _profit = 0;
            dataGridView2.Rows.Clear();
            try
            {
                cn.Open();
                cm = new SqlCommand("select ProductCode,  ProductName,price, sum(tax) as tot_tax, sum(qty)as tot_qty,sum(totalProductPrice) as tot_totalProductPrice,sum(discount)as tot_discount,sum(totalPriceqty) as tot_totalPriceqty,sum(profit)as tot_profit from tblSales where TransactionDate between'" + dtSales1.Value.ToString("dd-MM-yyyy") + "' and'" + dtSales2.Value.ToString("dd-MM-yyyy") + "' group by  ProductCode, ProductName,price", cn);

                dr = cm.ExecuteReader();

                while (dr.Read())
                {
                    i += 1;

                    _profit += double.Parse(dr["tot_profit"].ToString());
                    _total += double.Parse(dr["tot_totalPriceqty"].ToString());      
                    dataGridView2.Rows.Add(i, dr["ProductCode"].ToString(), dr["ProductName"].ToString(), dr["price"].ToString(), dr["tot_tax"].ToString(), dr["tot_qty"].ToString(), dr["tot_totalProductPrice"].ToString(), dr["tot_discount"].ToString(), dr["tot_totalPriceqty"].ToString(), dr["tot_profit"].ToString());
                    lblTotal.Text = _total.ToString("Sales Ghc:#,##0.00");
                    lblProfit.Text = _profit.ToString("Profit Ghc:#,##0.00");
                }
            }
            //dr.Close();
            //cn.Close();           
            catch (Exception ex)
            {
                // Handle or log the exception appropriately
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
