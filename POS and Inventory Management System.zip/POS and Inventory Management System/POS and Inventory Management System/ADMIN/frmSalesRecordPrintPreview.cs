﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_and_Inventory_Management_System.ADMIN
{
    public partial class frmSalesRecordPrintPreview : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        dbConnection dbcon = new dbConnection();
       
        frm_SalesRecord frm;
        public frmSalesRecordPrintPreview(frm_SalesRecord flist)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            this.frm = flist;
        }

        private void frmSalesRecordPrintPreview_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }

       
        public void LoadSalesRecord(string sql, string param)
        {
            DataSet ds = new DataSet();
            try
            {
                ReportDataSource rptD;
                this.reportViewer1.LocalReport.ReportPath = Application.StartupPath + @"\Report\rptSalesRecord.rdlc";
                this.reportViewer1.LocalReport.DataSources.Clear();               
                SqlDataAdapter da = new SqlDataAdapter();
                cn.Open();
                da.SelectCommand = new SqlCommand(sql, cn);
                da.Fill(ds.Tables["dtSalesReport"]);
                cn.Close();
                ReportParameter pDate = new ReportParameter("pDate", param);
                reportViewer1.LocalReport.SetParameters(pDate);
                rptD = new ReportDataSource("DataSet1", ds.Tables["dtSalesReport"]);
                reportViewer1.LocalReport.DataSources.Add(rptD);
                reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
                reportViewer1.ZoomMode = ZoomMode.Percent;
                reportViewer1.ZoomPercent = 100;
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
