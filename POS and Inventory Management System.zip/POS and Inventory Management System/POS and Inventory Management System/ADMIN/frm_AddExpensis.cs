﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_and_Inventory_Management_System.ADMIN
{
    public partial class frm_AddExpensis : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        dbConnection dbcon = new dbConnection();
        SqlDataReader dr;
        frm_Expensis fm;
        public frm_AddExpensis(frm_Expensis flist)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            this.fm = flist;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Clear()
        {
            txt_Description.Clear();
            txt_UnitPrice.Clear();
            txt_Qty.Clear();
            txt_Total.Clear();
            txt_Approvedby.Clear();
            btn_Save.Enabled = true;
            btn_Update.Enabled = false;
        }

        public bool IsValidated()
        {
            if (txt_Description.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Description is required?", "Error", MessageBoxButtons.OK, MessageBoxIcon.Question);
                txt_Description.Focus();
                return false;
            }
            if (txt_Approvedby.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Approved is required?", "Error", MessageBoxButtons.OK, MessageBoxIcon.Question);
                txt_Approvedby.Focus();
                return false;
            }

            if (txt_UnitPrice.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Unit price is required?", "Error", MessageBoxButtons.OK, MessageBoxIcon.Question);
                txt_UnitPrice.Focus();
                return false;
            }
            else
            {
                decimal Price;
                bool isDecimal = decimal.TryParse(txt_UnitPrice.Text.Trim(), out Price);
                if (!isDecimal)
                {
                    MessageBox.Show("Price should be a figure?", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txt_UnitPrice.Clear();
                    txt_UnitPrice.Focus();
                    return false;

                }
            }
            if (txt_Qty.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Quantity is required?", "Error", MessageBoxButtons.OK, MessageBoxIcon.Question);
                txt_Qty.Focus();
                return false;
            }
            else
            {
                decimal quantity;
                bool isDecimal = decimal.TryParse(txt_Qty.Text.Trim(), out quantity);
                if (!isDecimal)
                {
                    MessageBox.Show("Quantity should be a figure?", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txt_Qty.Clear();
                    txt_Qty.Focus();
                    return false;

                }
            }
            if (txt_Total.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Total price is required?", "Error", MessageBoxButtons.OK, MessageBoxIcon.Question);
                txt_Total.Focus();
                return false;
            }
            else
            {
                decimal Total;
                bool isDecimal = decimal.TryParse(txt_Total.Text.Trim(), out Total);
                if (!isDecimal)
                {
                    MessageBox.Show("Price should be a figure?", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txt_Total.Clear();
                    txt_Total.Focus();
                    return false;

                }
            }
            return true;
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (IsValidated())
            {
                try
                {
                    if (MessageBox.Show("Please confirm if you want to save this expensis?",
                        "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        cn.Open();
                        cm = new SqlCommand("INSERT INTO tblExpensis(ExpensisDate,Description,UnitPrice, Qty,Total ,Approvedby) VALUES(@ExpensisDate,@Description,@UnitPrice, @Qty, @Total,@Approvedby)", cn);
                        cm.Parameters.AddWithValue("@ExpensisDate", dtExpensisDate.Value.ToString("dd-MM-yyyy"));
                        cm.Parameters.AddWithValue("@Description", txt_Description.Text);
                        cm.Parameters.AddWithValue("@UnitPrice", txt_UnitPrice.Text);
                        cm.Parameters.AddWithValue("@Qty", txt_Qty.Text);
                        cm.Parameters.AddWithValue("@Total", txt_Total.Text);
                        cm.Parameters.AddWithValue("@Approvedby", txt_Approvedby.Text);
                        cm.ExecuteNonQuery();
                        cn.Close();
                        MessageBox.Show("Expensis has been successfully saved!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Clear();
                        fm.LoadExpensis();
                    }
                }
                catch (Exception ex)
                {
                    cn.Close();
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Please confirm if you want to update this expensis?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                   
                    cn.Open();
                    cm = new SqlCommand("UPDATE tblExpensis SET ExpensisDate=@ExpensisDate,Description=@Description, UnitPrice=@UnitPrice, Qty=@Qty,Total=@Total,Approvedby=@Approvedby where ExpensisId like '" + lblID.Text + "'", cn);
                    cm.Parameters.AddWithValue("@ExpensisDate", dtExpensisDate.Value.ToString("dd-MM-yyyy"));
                    cm.Parameters.AddWithValue("@Description", txt_Description.Text);
                    cm.Parameters.AddWithValue("@UnitPrice", txt_UnitPrice.Text);
                    cm.Parameters.AddWithValue("@Qty", txt_Qty.Text);
                    cm.Parameters.AddWithValue("@Total", txt_Total.Text);
                    cm.Parameters.AddWithValue("@Approvedby", txt_Approvedby.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Product has been successfully updated!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                   fm.LoadExpensis();
                    this.Close();

                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_CLEAR_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}