﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_and_Inventory_Management_System.ADMIN
{
    public partial class frm_Expensis : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        dbConnection dbcon = new dbConnection();
        SqlDataReader dr;
      
        public frm_Expensis()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            LoadExpensis();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            frm_AddExpensis frm = new frm_AddExpensis(this);
            frm.btn_Save.Enabled = true;
            frm.btn_Update.Enabled = false;
            LoadExpensis();
            frm.Show();
        }

        public void LoadExpensis()
        {
            int i = 0;
           
            dataGridView2.Rows.Clear();

            try
            {
                
                cn.Open();
                cm = new SqlCommand("select ExpensisId,  ExpensisDate,Description, UnitPrice,Qty,Total,Approvedby from tblExpensis where ExpensisDate between'" + dtExpensis1.Value.ToString("dd-MM-yyyy") + "' and'" + dtExpensis2.Value.ToString("dd-MM-yyyy") + "'", cn);
                dr = cm.ExecuteReader();
                while (dr.Read())
                {
                    i++;
                    DateTime formattedFDate = Convert.ToDateTime(dr["ExpensisDate"]);
                    string ExpensisDate = formattedFDate.ToString("dd-MM-yyyy");
                   // _total += double.Parse(dr["Total"].ToString());
                    dataGridView2.Rows.Add(i, dr["ExpensisId"].ToString(), ExpensisDate, dr["Description"].ToString(), dr["UnitPrice"].ToString(), dr["Qty"].ToString(), dr["Total"].ToString(), dr["Approvedby"].ToString());
                  //  lblTotal.Text = _total.ToString("#,##0.00");
                }
                dr.Close();
                cn.Close();
            }
            catch (Exception ex)
            {
                dr.Close();
                cn.Close();
                MessageBox.Show(ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnLoadData_Click(object sender, EventArgs e)
        {
              double _total = 0;
            int i = 0;
            dataGridView2.Rows.Clear();
            cn.Open();
            cm = new SqlCommand("Select * from tblExpensis where ExpensisDate between'" + dtExpensis1.Value.ToString("dd-MM-yyyy") + "'and'" + dtExpensis2.Value.ToString("dd-MM-yyyy") + "%'", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i += 1;
                // Parse the FDate column as a DateTime object
                DateTime fDate = Convert.ToDateTime(dr["ExpensisDate"]);
                // Format the date as dd/MM/yyyy
                string formattedFDate = fDate.ToString("dd-MM-yyyy");
                _total += double.Parse(dr["Total"].ToString());
                dataGridView2.Rows.Add(i, dr["ExpensisId"].ToString(), formattedFDate, dr["Description"].ToString(), dr["UnitPrice"].ToString(), dr["Qty"].ToString(), dr["Total"].ToString(), dr["Approvedby"].ToString());
            }
            dr.Close();
            cn.Close();
            lblTotal.Text = _total.ToString("Ghc #,##0.00");
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            frmPrintExpensisView frm = new frmPrintExpensisView();
            frm.LoadExpensis("select ExpensisId,ExpensisDate, Description, UnitPrice,Qty,Total,Approvedby, sum(Qty) as tot_Qty,  sum(Total) as Total from tblExpensis where ExpensisDate between '" + dtExpensis1.Value.ToString("dd-MM-yyyy") + "'and '" + dtExpensis2.Value.ToString("dd-MM-yyyy") + "'group by ExpensisId, ExpensisDate, Description, UnitPrice,Qty,Total,Approvedby", "From-:" + dtExpensis1.Value.ToString("dd-MM-yyyy") + "-To:-" + dtExpensis2.Value.ToString("dd-MM-yyyy"));
            frm.Show();

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColName = dataGridView2.Columns[e.ColumnIndex].Name;
            if (ColName == "Edit")
            {
                frm_AddExpensis frm = new frm_AddExpensis(this);
                frm.btn_Update.Enabled = true;
                frm.btn_Save.Enabled = false;
                frm.lblID.Text = dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString();
                frm.dtExpensisDate.CustomFormat = dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString();
                frm.txt_Description.Text = dataGridView2.Rows[e.RowIndex].Cells[3].Value.ToString();
                frm.txt_UnitPrice.Text = dataGridView2.Rows[e.RowIndex].Cells[4].Value.ToString();
                frm.txt_Qty.Text = dataGridView2.Rows[e.RowIndex].Cells[5].Value.ToString();
                frm.txt_Total.Text = dataGridView2.Rows[e.RowIndex].Cells[6].Value.ToString();
                frm.txt_Approvedby.Text = dataGridView2.Rows[e.RowIndex].Cells[7].Value.ToString();
               
                frm.Show();
                LoadExpensis();
            }
            else if (ColName == "Delete")
            {
                if (MessageBox.Show("DELETE THIS RECORD? CLICK YES TO CONFIRM", "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("delete from tblExpensis where ExpensisId like '" + dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("The Record has been successfully deleted.");
                    LoadExpensis();
                }
            }
        }


        }
    }

