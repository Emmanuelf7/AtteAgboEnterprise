﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_and_Inventory_Management_System.CASHIER
{
    public partial class frm_SalesReport : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        dbConnection dbcon = new dbConnection();
        SqlDataReader dr;
        public string suser;
        public frm_SalesReport()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            dt1.Value = DateTime.Now;
            dt2.Value = DateTime.Now;
            LoadSalesReport();
            LoadCashier();
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            frm_PrintSalesReport frm = new frm_PrintSalesReport(this);
            frm.LoadReport();
            frm.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void LoadSalesReport()
        {
            int i = 0;
            double _total = 0;
            dataGridView1.Rows.Clear();
            cn.Open();
            try
            {


                if (cboCashier.Text == "All Cashier")
                {
                    cm = new SqlCommand("select SalesId, TransactionDate,ProductCode, TransactionNo,  ProductName, category,price,tax, qty,totalProductPrice,totalPriceqty,discount,payMode from tblSales  where TransactionDate between'" + dt1.Value.ToString("dd-MM-yyyy") + "' and'" + dt2.Value.ToString("dd-MM-yyyy") + "'", cn);
                }
                else
                {
                    cm = new SqlCommand("select SalesId, TransactionDate,ProductCode, TransactionNo, ProductName, category,price,tax, qty,totalProductPrice,totalPriceqty,discount,payMode from tblSales where TransactionDate between'" + dt1.Value.ToString("dd-MM-yyyy") + "' and'" + dt2.Value.ToString("dd-MM-yyyy") + "'and cashier like '" + cboCashier.Text + "'", cn);
                }
                dr = cm.ExecuteReader();

                while (dr.Read())
                {
                    i += 1;
                    // Parse the FDate column as a DateTime object
                    DateTime fDate = Convert.ToDateTime(dr["TransactionDate"]);
                    // Format the date as dd/MM/yyyy
                    string formattedFDate = fDate.ToString("dd-MM-yyyy");
                    _total += double.Parse(dr["totalPriceqty"].ToString());
                    dataGridView1.Rows.Add(i, dr["SalesId"].ToString(), formattedFDate, dr["ProductCode"].ToString(), dr["TransactionNo"].ToString(), dr["ProductName"].ToString(), dr["category"].ToString(), dr["price"].ToString(), dr["tax"].ToString(), dr["qty"].ToString(), dr["totalProductPrice"].ToString(), dr["totalPriceqty"].ToString(), dr["discount"].ToString(), dr["payMode"].ToString());
                    lblTotal.Text = _total.ToString("#,##0.00");
                }
            }
            catch (Exception ex)
            {
                // Handle or log the exception appropriately
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            //dr.Close();
            //cn.Close();           
          
        }




        public void LoadCashier()
        {
            cboCashier.Items.Clear();
            cboCashier.Items.Add("All Cashier");
            cn.Open();
            cm = new SqlCommand("select * from tblUser where Role like 'Cashier'", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                cboCashier.Items.Add(dr["UserName"].ToString());
            }
            dr.Close();
            cn.Close();
        }

        private void cboCashier_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadSalesReport();
        }

        private void dt1_ValueChanged(object sender, EventArgs e)
        {
            LoadSalesReport();
        }

        private void dt2_ValueChanged(object sender, EventArgs e)
        {
            LoadSalesReport();
        }

        private void cboCashier_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
            string ColName = dataGridView1.Columns[e.ColumnIndex].Name;
           
            if (ColName == "dgvDelete")
            {
                if (MessageBox.Show("DELETE THIS RECORD? CLICK YES TO CONFIRM", "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("delete from tblSales where SalesId like '" + dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("The Record has been successfully deleted.");
                    LoadSalesReport();
                }
            }
        }

        }

    }

